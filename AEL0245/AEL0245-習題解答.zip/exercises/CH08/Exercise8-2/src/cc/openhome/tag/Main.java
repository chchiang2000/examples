package cc.openhome.tag;

import javax.servlet.jsp.PageContext;

public class Main {
    public static void main(String[] args) {
        System.out.println(PageContext.APPLICATION);
    }

}
