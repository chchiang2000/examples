package cc.openhome;

import java.io.Serializable;
import java.sql.*;
import javax.naming.*;
import javax.sql.DataSource;

public class DatabaseBean implements Serializable {

} 
